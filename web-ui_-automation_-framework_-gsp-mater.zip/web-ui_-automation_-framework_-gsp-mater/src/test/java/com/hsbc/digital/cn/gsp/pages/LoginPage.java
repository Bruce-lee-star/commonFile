package com.hsbc.digital.cn.gsp.pages;


import org.openqa.selenium.WebDriver;

public class LoginPage {

    public String usernameInputById = "username";

    public String loginWarnByXpath = "//div[contains(text(),'远离诈骗陷阱')]";

    public String continueBtnById = "username_submit_btn";

    public String closeMigrationPopUpById = "linkClose-otpMigration";

    public String otpInputById = "otp";

    public String loginBtnById = "loginBtn";

    public String trustBrowserRadioById = "TB_YES";

    public String trustBrowserLoginBtnById = "trusted_logon_button";

}
