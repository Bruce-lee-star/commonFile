package com.hsbc.digital.cn.gsp.utils;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class WebDriverUtils {

    static WebDriver driver;

    public static void setDriver(WebDriver driver) {
        WebDriverUtils.driver = driver;
    }

    public static WebDriver getDriver(){
        return driver;
    }

    public static WebDriver Open(String browser){
        if(driver != null){
            return driver;
        }else {
            String driverPath = System.getProperty("user.dir") + "\\src\\test\\resources\\drivers\\";
            try {
                if (browser.toLowerCase(Locale.ROOT).equalsIgnoreCase("firefox")) {
                    System.setProperty("webdriver.gecko.driver", driverPath + "geckodriver.exe");
                    //设置日志位置
                    System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE, "/dev/null");
                    if(ExtensionUtils.macAddressExtensionPath != null){
                        FirefoxProfile profile = new FirefoxProfile();
                        File extensionFile = new File(System.getProperty("user.dir") + ExtensionUtils.macAddressExtensionPath);
                        profile.addExtension(extensionFile);
                        FirefoxOptions firefoxOptions = new FirefoxOptions();
                        firefoxOptions.setProfile(profile);
                        driver = new FirefoxDriver(firefoxOptions);
                    }else{
                        driver = new FirefoxDriver();
                    }
                    setDriver(driver);
                    driver.manage().window().maximize();
                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                    return driver;
                } else if (browser.toLowerCase(Locale.ROOT).equalsIgnoreCase("chrome")) {
                    System.setProperty("webdriver.chrome.driver", driverPath + "chromedriver.exe");

                    if (ExtensionUtils.macAddressExtensionPath != null) {
                        ChromeOptions chromeOptions = new ChromeOptions();
                        chromeOptions.addExtensions(new File(System.getProperty("user.dir") + ExtensionUtils.macAddressExtensionPath));
                        driver = new ChromeDriver(chromeOptions);
                    } else {
                        driver = new ChromeDriver();
                    }
                    setDriver(driver);
                    driver.manage().window().maximize();
                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                    return driver;
                } else if (browser.toLowerCase(Locale.ROOT).equalsIgnoreCase("edge")) {
                    System.setProperty("webdriver.edge.driver", driverPath + "msedgedriver.exe");
                    driver = new EdgeDriver();
                    setDriver(driver);
                    driver.manage().window().maximize();
                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                    return driver;
                }
            }catch (Exception e){

            }finally {
                ExtensionUtils.macAddressExtensionPath = null;
            }
            return null;
        }
    }

}
