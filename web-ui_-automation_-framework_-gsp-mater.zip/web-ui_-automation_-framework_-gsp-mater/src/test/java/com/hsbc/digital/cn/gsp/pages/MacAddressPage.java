package com.hsbc.digital.cn.gsp.pages;


import net.serenitybdd.core.pages.PageObject;


public class MacAddressPage extends PageObject {


    // install pop up
    public String macAddressHeaderByCss = "[data-dojo-attach-point='captureMacAddressHeadingNode_firstInstall']";

    public String macAddressDescByCss = "[data-dojo-attach-point='cptMacAddrContentDsec1_firstInstall']>p";

    public String macAddressStep1ByCss = "[data-dojo-attach-point='cptMacAddrContentDsec1_firstInstall']+p";

    public String macAddressStep2ByCss = "[data-dojo-attach-point='cptMacAddrContentDsec1_firstInstall']+p+p";

    public String macAddressInstallDescByCss = "[data-dojo-attach-point='cptMacAddrContentDsec1_firstInstall']+p+p+p";

    public String installBtnByCss = "[data-dojo-attach-point='yesDiscard']";

    public String remindLaterBtnByCss = "[data-dojo-attach-point='noDiscard']";

    //init Install Page
    public String pageHeaderByCss = ".header__title>span";

    //init Introduce
    public String introHeaderById = "content-nls-introduction-header";
    public String introDesc1ById = "content-nls-introduction-1";
    public String introDesc2ById = "content-nls-introduction-2";

    //init Step1
    public String step1ByCss = "h2[class='firstInstallContent'][id='content-nls-step-1-header']";
    public String step1_1ById = "content-nls-step-1-1";
    public String step1_2ById = "content-nls-step-1-2";
    public String step1_3ById = "content-nls-step-1-3";
    public String step1_4ById = "content-nls-step-1-4";


    //home page
    public String accountSelectedByCss = "span.selected";
    public String logoffBtnByCss = "li.logOff>a";


    //logoff page
    public String logoffInfoByCss = "#content_intro_hero_no_image_1";

    //edge
    public String getEdgeExtensionByCss = "div[aria-label='获取 HSBC-China Personal Online Banking extension']";

    // host upgrade pop up
    public String macAddrHostUpgradeHeaderByCss = "h2[data-dojo-attach-point='captureMacAddressHeadingNode_hostUpgrade']";
    public String macAddrHostUpgradeDesc1ByCss = "div[data-dojo-attach-point='cptMacAddrContentDsec1_hostUpgrade']>p:first-child";
    public String macAddrHostUpgradeDesc2ByCss = "div[data-dojo-attach-point='cptMacAddrContentDsec1_hostUpgrade']>p:nth-child(2)";
    public String macAddrHostUpgradeDesc3ByCss = "div[data-dojo-attach-point='cptMacAddrContentDsec1_hostUpgrade']+p";
    public String macAddrHostUpgradeDesc4ByCss = "div[data-dojo-attach-point='cptMacAddrContentDsec1_hostUpgrade']+p+p";
    public String macAddrHostUpgradeDesc5ByCss = "div[data-dojo-attach-point='cptMacAddrContentDsec1_hostUpgrade']+p+p+p";

    //host upgrade install page
    public String hostUpgradeStep1ByCss = "h2[class='hostUpgradeContent'][id='content-nls-step-1-header']";
    public String hostUpgradeIntro2 = "[id='content-nls-introduction-2'][class$='hostUpgradeContent']";


}
