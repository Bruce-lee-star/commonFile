package com.hsbc.digital.cn.gsp.utils;

public class ExtensionUtils {
    public static String macAddressExtensionPath;

}
