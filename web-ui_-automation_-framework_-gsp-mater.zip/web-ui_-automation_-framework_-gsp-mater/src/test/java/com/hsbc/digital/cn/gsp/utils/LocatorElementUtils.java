package com.hsbc.digital.cn.gsp.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class LocatorElementUtils {

    public static WebElement getElementByID(String locator){
       return WebDriverUtils.getDriver().findElement(By.id(locator));
    }


    public static WebElement getElementByCSS(String locator){
        return WebDriverUtils.getDriver().findElement(By.cssSelector(locator));
    }


    public static WebElement getElementByXpath(String locator){
        return WebDriverUtils.getDriver().findElement(By.xpath(locator));
    }

    public static WebElement getElementByName(String locator){
        return WebDriverUtils.getDriver().findElement(By.name(locator));
    }

    public static WebElement getElementByTagName(String locator){
        return WebDriverUtils.getDriver().findElement(By.tagName(locator));
    }

    public static WebElement getElementByLinkText(String locator){
        return WebDriverUtils.getDriver().findElement(By.linkText(locator));
    }

    public static WebElement getElementByPartialLinkText(String locator){
        return WebDriverUtils.getDriver().findElement(By.partialLinkText(locator));
    }

    public static WebElement getElementByClassName(String locator){
        return WebDriverUtils.getDriver().findElement(By.className(locator));
    }
}
