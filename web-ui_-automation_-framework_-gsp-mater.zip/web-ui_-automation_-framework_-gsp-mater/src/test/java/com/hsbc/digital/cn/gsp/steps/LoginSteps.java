package com.hsbc.digital.cn.gsp.steps;

import com.hsbc.digital.cn.gsp.pages.LoginPage;
import com.hsbc.digital.cn.gsp.utils.ExtensionUtils;
import com.hsbc.digital.cn.gsp.utils.LocatorElementUtils;
import com.hsbc.digital.cn.gsp.utils.WebDriverUtils;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.steps.UIInteractionSteps;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.util.EnvironmentVariables;
import org.openqa.selenium.*;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;


import static net.serenitybdd.rest.SerenityRest.rest;
import static net.serenitybdd.rest.SerenityRest.useRelaxedHTTPSValidation;

public class LoginSteps extends UIInteractionSteps {


    private LoginPage loginPage = new LoginPage();
    private static EnvironmentVariables envVariable;
    private static String url;
    private static String username;
    private static String securityCodeUrl;

    private static String splashUserName = "amsuser";
    private static String splashPwd = "Pr0tectamsuser";

    private boolean isRelogin = false;


    public void getConfig(String env){
        if (envVariable.getProperty("environment") != null) {
            env = envVariable.getProperty("environment");
        }
        url = envVariable.getProperty("environments." + env + ".webdriver.base.url");
        username = envVariable.getProperty("environments." + env + ".username");
        securityCodeUrl = envVariable.getProperty("environments." + env + ".security.token.url");
    }

    public String getSecurityCode(){
        useRelaxedHTTPSValidation();
        return rest().when().log().all().get(securityCodeUrl).then().log().all().extract().jsonPath().get("token");
    }

    public void copyAndPasteString(String str){
        StringSelection stringSelection = new StringSelection(str);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection,null);
        KeyBoard(KeyEvent.VK_CONTROL,KeyEvent.VK_V);
    }
    public void sleep(int n){
        try {
            Thread.sleep(n*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void KeyBoard(Integer key1,Integer key2){
        try{
            Robot robot = new Robot();
            robot.keyPress(key1);
            if(key2 != null){
                robot.keyPress(key2);
            }
            robot.delay(1000);
            robot.keyRelease(key1);
            if(key2 != null){
                robot.keyRelease(key2);
            }
            robot.delay(1000);
        }catch (Exception e){

        }
    }

    @Step
    public void loginGSPTestEnvironmentUsingBrowser(String env, String browser){
        getConfig(env);
        WebDriver webDriver = WebDriverUtils.Open(browser);
        webDriver.get(url);
        splashAuth();
        while(webDriver.findElements(By.xpath(loginPage.loginWarnByXpath)).size() != 0){
            webDriver.navigate().refresh();
            sleep(5);
            LocatorElementUtils.getElementByID(loginPage.usernameInputById).sendKeys(username);
            LocatorElementUtils.getElementByID(loginPage.continueBtnById).click();
            sleep(8);
        }
        if(LocatorElementUtils.getElementByID(loginPage.closeMigrationPopUpById).isDisplayed()) {
            LocatorElementUtils.getElementByID(loginPage.closeMigrationPopUpById).click();
        }
        LocatorElementUtils.getElementByID(loginPage.otpInputById).sendKeys(getSecurityCode());
        LocatorElementUtils.getElementByID(loginPage.loginBtnById).click();
        if(!isRelogin) {
            LocatorElementUtils.getElementByID(loginPage.trustBrowserRadioById).click();
            LocatorElementUtils.getElementByID(loginPage.trustBrowserLoginBtnById).click();
        }
        sleep(10);
        splashAuth();
        sleep(8);
        Serenity.takeScreenshot();
    }

    private void splashAuth(){
        if(!isRelogin) {
            sleep(5);
            KeyBoard(KeyEvent.VK_ENTER, null);
            copyAndPasteString(splashUserName);
            KeyBoard(KeyEvent.VK_TAB, null);
            copyAndPasteString(splashPwd);
            KeyBoard(KeyEvent.VK_ENTER, null);
            sleep(3);
        }
    }
    @Before
    public void before(Scenario scenario){
        ExtensionUtils.macAddressExtensionPath = null;
    }

    @After
    public void after(Scenario scenario){
        WebDriverUtils.getDriver().quit();
        WebDriverUtils.setDriver(null);
        Serenity.getWebdriverManager().closeAllDrivers();
    }

    @Step
    public void changeGspLanguageWithOtherLanguage() {
        WebDriver driver = WebDriverUtils.getDriver();
        boolean flag = driver.manage().getCookieNamed("HSBC_CLIENT_COOKIE").getValue().contains("zh_CN");
        String languageValue = !flag ? "PreferredLocale=zh_CN" : "PreferredLocale=en_CN";
        driver.manage().deleteCookieNamed("HSBC_CLIENT_COOKIE");
        driver.manage().addCookie(new Cookie("HSBC_CLIENT_COOKIE",languageValue));
        driver.navigate().refresh();
        sleep(5);
    }

    @Step
    public void reLoginGSPTestEnvironmentUsingBrowser(String env, String browser) {
        isRelogin = true;
        loginGSPTestEnvironmentUsingBrowser(env,browser);
    }
}
