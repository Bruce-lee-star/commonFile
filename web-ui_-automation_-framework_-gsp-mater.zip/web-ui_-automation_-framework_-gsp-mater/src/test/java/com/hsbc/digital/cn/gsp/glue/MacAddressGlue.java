package com.hsbc.digital.cn.gsp.glue;

import com.hsbc.digital.cn.gsp.steps.MacAddressSteps;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class MacAddressGlue {
    @Steps
    private MacAddressSteps macAddressSteps;

    @Then("^check the mac address install pop up copy$")
    public void checkTheMacAddressInstallPopUpCopy() {
        macAddressSteps.checkTheMacAddressInstallPopUpCopy();
    }

    @When("^click how to install button in mac address page$")
    public void clickHowToInstallButtonInMacAddressPage() {
        macAddressSteps.clickHowToInstallButtonInMacAddressPage();
    }

    @And("^switch new window handle$")
    public void switchNewWindowHandle() {
        macAddressSteps.switchNewWindowHandle();
    }

    @Then("^check the install page copy in mac address page on \"([^\"]*)\" browser$")
    public void checkTheInstallPageCopyInMacAddressPageOnBrowser(String browser) {
        macAddressSteps.checkTheInstallPageCopyInMacAddressPageOnBrowser(browser);
    }

    @And("^check the home page will display$")
    public void checkTheHomePageWillDisplay() {
        macAddressSteps.checkTheHomePageWillDisplay();
    }

    @When("^click remind me later button in mac address page$")
    public void clickRemindMeLaterButtonInMacAddressPage() {
        macAddressSteps.clickRemindMeLaterButtonInMacAddressPage();
    }

    @When("^click logoff button in home page$")
    public void clickLogoffButtonInHomePage() {
        macAddressSteps.clickLogoffButtonInHomePage();
    }

    @Then("^check user logoff system successfully$")
    public void checkUserLogoffSystemSuccessfully() {
        macAddressSteps.checkUserLogoffSystemSuccessfully();
    }

    @And("^close new open window handle$")
    public void closeNewOpenWindowHandle() {
        macAddressSteps.closeNewOpenWindowHandle();
    }

    @And("^set mac address expires$")
    public void setMacAddressExpires() {
        macAddressSteps.setMacAddressExpires();
    }

    @And("^install \"([^\"]*)\" driver and \"([^\"]*)\" extension with \"([^\"]*)\" browser$")
    public void installDriverAndExtension(String driverVersion, String extensionVersion,String browser) {
        macAddressSteps.installDriverAndExtension(driverVersion,extensionVersion,browser);
    }

    @Then("^check the mac address driver upgrade pop up copy$")
    public void checkTheMacAddressDriverUpgradePopUpCopy() {
        macAddressSteps.checkTheMacAddressDriverUpgradePopUpCopy();
    }

    @When("^click how to update button in driver upgrade pop up$")
    public void clickHowToUpdateButtonInDriverUpgradePopUp() {
        macAddressSteps.clickHowToInstallButtonInMacAddressPage();
    }

    @Then("^check the driver upgrade page copy in mac address page on \"([^\"]*)\" browser$")
    public void checkTheDriverUpgradePageCopyInMacAddressPageOnBrowser(String browser){
        macAddressSteps.checkTheDriverUpgradePageCopyInMacAddressPageOnBrowser(browser);
    }
}
