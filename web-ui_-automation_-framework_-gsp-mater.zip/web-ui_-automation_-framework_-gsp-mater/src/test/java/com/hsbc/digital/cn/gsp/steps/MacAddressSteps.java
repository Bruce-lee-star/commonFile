package com.hsbc.digital.cn.gsp.steps;

import com.hsbc.digital.cn.gsp.pages.MacAddressPage;
import com.hsbc.digital.cn.gsp.utils.ExtensionUtils;
import com.hsbc.digital.cn.gsp.utils.LocatorElementUtils;
import com.hsbc.digital.cn.gsp.utils.WebDriverUtils;
import net.serenitybdd.core.steps.UIInteractionSteps;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

public class MacAddressSteps extends UIInteractionSteps {

    private MacAddressPage macAddressPage = new MacAddressPage();
    private String macAddressExtensionPath;


    private String driverAndExtensionPath = System.getProperty("user.dir") + "\\src\\test\\resources\\MacAddress\\";


    private boolean returnLanguageFlag(){
        return WebDriverUtils.getDriver().manage().getCookieNamed("HSBC_CLIENT_COOKIE").getValue().contains("zh_CN");
    }

    @Step
    public void checkTheMacAddressInstallPopUpCopy() {
        boolean flag = returnLanguageFlag();
        String macAddressHeader = flag ? "获取媒体访问控制（MAC）地址" : "MAC address capture - action required";
        String macAddressDesc = flag ? "即日起，为落实中国国家金融监督管理总局监管要求，在您使用中国账户操作交易授权时，我行将对您设备的媒体访问控制（MAC）地址进行数据采集并上报。整个安装过程需要您完成以下两项操作，大约需要5分钟。此过程无需重启您的设备。如需任何帮助，请与您的系统管理员联系。" :
                "In order to comply with the regulations in China, we are required to capture and report to the National Financial Regulatory Administration in China your device’s Media Access Control (MAC) address when authorizing payments from a China debit account. To complete this process, you will need to perform two actions:";
        String macAddressStep1 = flag ? "1. 下载并安装应用程序至您的设备" : "1. Download and install a program to your device.";
        String macAddressStep2 = flag ? "2. 安装浏览器扩展程序" : "2. Install a browser extension.";
        String macAddressInstallDesc = flag ? "整个过程大约需要5分钟。请点击以下“安装向导”按钮以完成全部程序安装。" : "This process will take approximately 5 minutes. Please select the ‘How to install’ button below to complete the installation.";
        sleep(5);
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddressHeaderByCss).getText(),equalTo(macAddressHeader));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddressDescByCss).getText(),equalTo(macAddressDesc));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddressStep1ByCss).getText(),equalTo(macAddressStep1));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddressStep2ByCss).getText(),equalTo(macAddressStep2));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddressInstallDescByCss).getText(),equalTo(macAddressInstallDesc));
    }

    @Step
    public void clickHowToInstallButtonInMacAddressPage() {
        LocatorElementUtils.getElementByCSS(macAddressPage.installBtnByCss).click();
    }

    @Step
    public void switchNewWindowHandle() {
        WebDriver driver = WebDriverUtils.getDriver();
        String windowHandle = driver.getWindowHandle();
        for(String temHandle : driver.getWindowHandles()){
            if(!(windowHandle.equals(temHandle))){
                driver.switchTo().window(temHandle);
            }
        }
    }

    public void sleep(int n){
        try {
            Thread.sleep(n*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Step
    public void checkTheInstallPageCopyInMacAddressPageOnBrowser(String browser) {
        sleep(5);
        boolean flag = returnLanguageFlag();
        String pageHeader = flag ? "获取媒体访问控制（MAC）地址安装向导" : "MAC address capture installation guide";
        String introHeader = flag ? "简介" : "Introduction";
        String introDesc1 = flag ? "即日起，为落实中国国家金融监督管理总局监管要求，在您使用中国账户操作交易授权时，我行将对您设备的媒体访问控制（MAC）地址进行数据采集并上报。" :
                "In order to comply with the regulations in China, we are required to capture and report to the National Financial Regulatory Administration in China your device's Media Access Control (MAC) address when authorizing payments from a China debit account.";
        String introDesc2 = flag ? "整个安装过程需要您完成以下两项操作，大约需要5分钟。此过程无需重启您的设备。如需任何帮助，请与您的系统管理员联系。" :
                "To complete this process, you will need to perform two actions, which will take about 5 minutes. No device restart is required. If you have any questions about this process, please contact your System Administrator.";
        String step1 = flag ? "步骤1：下载并安装驱动程序" : "Step 1: Download and install a program to your device";
        String step1_1 = flag ? "下载应用程序" : "Download the program";
        String step1_2 = flag ? "1.2 打开应用程序并点击“运行”" : "1.2 Open the file and click \"Run\".";
        String step1_3 = flag ? "1.3 点击“安装”" : "1.3 Click \"Install\"";
        String step1_4 = flag ? "1.4 当系统提示完成程序安装，点击“关闭”" : "1.4 Once the program is installed click on \"Close\".";

        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.pageHeaderByCss).getText(),equalTo(pageHeader));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.introHeaderById).getText(),equalTo(introHeader));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.introDesc1ById).getText(),equalTo(introDesc1));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.introDesc2ById).getText(),equalTo(introDesc2));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.step1ByCss).getText(),equalTo(step1));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.step1_1ById).getText(),containsString(step1_1));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.step1_2ById).getText(),equalTo(step1_2));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.step1_3ById).getText(),equalTo(step1_3));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.step1_4ById).getText(),equalTo(step1_4));

    }

    @Step
    public void checkTheHomePageWillDisplay() {
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.accountSelectedByCss).isDisplayed(),is(true));
    }

    @Step
    public void clickRemindMeLaterButtonInMacAddressPage() {
        LocatorElementUtils.getElementByCSS(macAddressPage.remindLaterBtnByCss).click();
        System.out.println(getMacAddressExpires("macAddressExpires"));
    }

    private String getMacAddressExpires(String key){
        WebDriver driver = WebDriverUtils.getDriver();
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor)driver;
        return (String) javascriptExecutor.executeScript(String.format("return window.localStorage.getItem('%s')",key));
    }

    private void setMacAddressExpires(Long value){
        WebDriver driver = WebDriverUtils.getDriver();
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor)driver;
        javascriptExecutor.executeScript(String.format("window.localStorage.setItem('macAddressExpires',%s)",value));
    }

    private void removeMacAddressExpires(){
        WebDriver driver = WebDriverUtils.getDriver();
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor)driver;
        javascriptExecutor.executeScript("window.localStorage.removeItem('macAddressExpires')");
    }

    private void openNewWindow(String url){
        WebDriver driver = WebDriverUtils.getDriver();
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor)driver;
        javascriptExecutor.executeScript(String.format("window.open('%s',\"_blank\")",url));
        sleep(5);
        switchNewWindowHandle();
    }

    @Step
    public void clickLogoffButtonInHomePage() {
        LocatorElementUtils.getElementByCSS(macAddressPage.logoffBtnByCss).click();
        sleep(3);
    }


    @Step
    public void checkUserLogoffSystemSuccessfully() {
        boolean flag = returnLanguageFlag();
        String logoffInfo = flag ? "您已成功登出账户" : "Log off successful";
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.logoffInfoByCss).getText(),containsString(logoffInfo));
    }

    @Step
    public void closeNewOpenWindowHandle() {
        WebDriver driver = WebDriverUtils.getDriver();
        String windowHandle = driver.getWindowHandle();
        for(String temHandle : driver.getWindowHandles()){
            if(!(windowHandle.equals(temHandle))){
                driver.switchTo().window(temHandle);
                driver.close();
                driver.switchTo().window(windowHandle);
            }
        }
    }

    @Step
    public void setMacAddressExpires() {
        setMacAddressExpires(System.currentTimeMillis());
        WebDriverUtils.getDriver().navigate().refresh();
        sleep(5);
    }

    @Step
    public void installDriverAndExtension(String driverVersion, String extensionVersion,String browser) {
        String osName = System.getProperty("os.name");
        String driverVer = driverVersion.equalsIgnoreCase("latest") ? "HSBC-ChinaPersonalOnlineBankingSetup.1.0.0.1.exe" : "HSBC-ChinaPersonalOnlineBankingSetup.1.0.0.0.exe";

        //String extensionVer = extensionVersion.equalsIgnoreCase("latest") ? "" : "";
        // install driver
        if(osName.contains("Win")){
            executeMacAddressDriver(System.getProperty("user.home")+"\\AppData\\Local\\Programs\\HSBC\\HSBC-China Personal Internet Banking\\uninst.exe");
            sleep(5);
            executeMacAddressDriver(driverAndExtensionPath+driverVer);

            if(browser.equalsIgnoreCase("edge")){
                ExtensionUtils.macAddressExtensionPath = extensionVersion.equalsIgnoreCase("latest") ? "https://microsoftedge.microsoft.com/addons/detail/hsbcchina-personal-onlin/nllgfggnffngdbaccefpejnmpkojmiep" : "";

                openNewWindow(ExtensionUtils.macAddressExtensionPath);
                LocatorElementUtils.getElementByCSS(macAddressPage.getEdgeExtensionByCss).click();
                sleep(2);
                KeyBoard(KeyEvent.VK_SHIFT,KeyEvent.VK_TAB);
                KeyBoard(KeyEvent.VK_ENTER,null);
                switchNewWindowHandle();
                closeNewOpenWindowHandle();
                WebDriverUtils.getDriver().navigate().refresh();
                sleep(6);
            }
            if(browser.equalsIgnoreCase("chrome")){
                ExtensionUtils.macAddressExtensionPath = extensionVersion.equalsIgnoreCase("latest") ? "\\src\\test\\resources\\MacAddress\\HSBC-ChinaPersonalInternetBankingExtension1.0.0.0.crx" : "\\src\\test\\resources\\MacAddress\\HSBC-ChinaPersonalInternetBankingExtension2.9.9.9.crx";

            }
            if(browser.equalsIgnoreCase("firefox")){
                ExtensionUtils.macAddressExtensionPath = extensionVersion.equalsIgnoreCase("latest") ? "\\src\\test\\resources\\MacAddress\\HSBC-ChinaPersonalInternetBankingExtension.xpi" : "\\src\\test\\resources\\MacAddress\\HSBC-ChinaPersonalInternetBankingExtension.xpi";

            }
        }
    }

    public void KeyBoard(Integer key1,Integer key2){
        try{
            Robot robot = new Robot();
            robot.keyPress(key1);
            if(key2 != null){
                robot.keyPress(key2);
            }
            robot.delay(1000);
            robot.keyRelease(key1);
            if(key2 != null){
                robot.keyRelease(key2);
            }
            robot.delay(1000);
        }catch (Exception e){

        }
    }


    public void executeMacAddressDriver(String driverPath){
        Runtime runtime = Runtime.getRuntime();
        Process process = null;
        try{
            process = runtime.exec(driverPath);
            process.waitFor(6,TimeUnit.SECONDS);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(process != null){
                if(process.isAlive()){
                    System.out.println(process.destroyForcibly().exitValue());
                    process.destroy();
                }else{
                    process.destroyForcibly();
                }
            }
        }
    }

    @Step
    public void checkTheMacAddressDriverUpgradePopUpCopy() {
        sleep(10);
        boolean flag = returnLanguageFlag();
        String hostUpgradeHeader = flag ? "有可用的驱动程序更新" : "Program update required";
        String macAddrHostUpgradeDesc1 = flag ? "上报您设备的媒体访问控制地址" : "Reporting your device’s MAC address";
        String macAddrHostUpgradeDesc2 = flag ? "即日起，为落实中国国家金融监督管理总局监管要求，在您使用中国账户操作交易授权时，我行将对您设备的媒体访问控制（MAC）地址进行数据采集并上报。" :
                "In order to comply with the regulations in China, we are required to capture and report to the National Financial Regulatory Administration in China your device’s Media Access Control (MAC) address when authorizing payments from a China debit account.";
        String macAddrHostUpgradeDesc3 = flag ? "您收到此消息是因为有更新的驱动程序可供下载。" : "You’re receiving this message because a program update is available.";
        String macAddrHostUpgradeDesc4 = flag ? "请更新并重新安装驱动程序。" : "Please update and reinstall the program.";
        String macAddrHostUpgradeDesc5 = flag ? "整个过程大约需要5分钟。" : "This process will take approximately 5 minutes.";
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddrHostUpgradeHeaderByCss).getText(),equalTo(hostUpgradeHeader));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddrHostUpgradeDesc1ByCss).getText(),equalTo(macAddrHostUpgradeDesc1));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddrHostUpgradeDesc2ByCss).getText(),equalTo(macAddrHostUpgradeDesc2));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddrHostUpgradeDesc3ByCss).getText(),equalTo(macAddrHostUpgradeDesc3));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddrHostUpgradeDesc4ByCss).getText(),equalTo(macAddrHostUpgradeDesc4));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.macAddrHostUpgradeDesc5ByCss).getText(),equalTo(macAddrHostUpgradeDesc5));
    }

    @Step
    public void checkTheDriverUpgradePageCopyInMacAddressPageOnBrowser(String browser) {
        sleep(5);
        boolean flag = returnLanguageFlag();
        String pageHeader = flag ? "获取媒体访问控制（MAC）地址安装向导" : "MAC address capture installation guide";
        String introHeader = flag ? "简介" : "Introduction";
        String introDesc1 = flag ? "即日起，为落实中国国家金融监督管理总局监管要求，在您使用中国账户操作交易授权时，我行将对您设备的媒体访问控制（MAC）地址进行数据采集并上报。" :
                "In order to comply with the regulations in China, we are required to capture and report to the National Financial Regulatory Administration in China your device's Media Access Control (MAC) address when authorizing payments from a China debit account.";
        String introDesc2 = flag ? "您收到此消息是因为有更新的驱动程序可供下载。整个过程大约需要5分钟。此过程无需重启您的设备。如需任何帮助，请与您的系统管理员联系。" :
                "You're receiving this message because an update to your browser extension is available. This process will take approximately 5 minutes. No device restart is required. If you have any questions about this process, please contact your System Administrator.";
        String step1 = flag ? "步骤1：更新并重新安装驱动程序" : "Step 1: Update and reinstall the program";
        String step1_1 = flag ? "下载应用程序" : "Download the program";
        String step1_2 = flag ? "1.2 打开应用程序并点击“运行”" : "1.2 Open the file and click \"Run\".";
        String step1_3 = flag ? "1.3 点击“安装”" : "1.3 Click \"Install\"";
        String step1_4 = flag ? "1.4 当系统提示完成程序安装，点击“关闭”" : "1.4 Once the program is installed click on \"Close\".";
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.pageHeaderByCss).getText(),equalTo(pageHeader));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.introHeaderById).getText(),equalTo(introHeader));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.introDesc1ById).getText(),equalTo(introDesc1));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.hostUpgradeIntro2).getText(),equalTo(introDesc2));
        assertThat(LocatorElementUtils.getElementByCSS(macAddressPage.hostUpgradeStep1ByCss).getText(),equalTo(step1));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.step1_1ById).getText(),containsString(step1_1));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.step1_2ById).getText(),equalTo(step1_2));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.step1_3ById).getText(),equalTo(step1_3));
        assertThat(LocatorElementUtils.getElementByID(macAddressPage.step1_4ById).getText(),equalTo(step1_4));
    }
}
