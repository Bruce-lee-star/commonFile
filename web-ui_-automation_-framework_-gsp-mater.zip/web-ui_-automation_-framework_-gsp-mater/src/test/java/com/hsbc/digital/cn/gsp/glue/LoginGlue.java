package com.hsbc.digital.cn.gsp.glue;

import com.hsbc.digital.cn.gsp.steps.LoginSteps;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;

public class LoginGlue {

    private LoginSteps loginSteps;

    @When("^Login \"([^\"]*)\" GSP test environment using \"([^\"]*)\" browser$")
    public void loginGSPTestEnvironmentUsingBrowser(String env, String browser) {
        loginSteps.loginGSPTestEnvironmentUsingBrowser(env,browser);
    }

    @And("^change gsp language with other language$")
    public void changeGspLanguageWithOtherLanguage() {
        loginSteps.changeGspLanguageWithOtherLanguage();
    }

    @When("^Re-Login \"([^\"]*)\" GSP test environment using \"([^\"]*)\" browser$")
    public void reLoginGSPTestEnvironmentUsingBrowser(String env, String browser) {
        loginSteps.reLoginGSPTestEnvironmentUsingBrowser(env,browser);
    }
}
